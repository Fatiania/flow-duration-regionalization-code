# Reproducible flow-duration analysis code package

This repository contains the Python scripts used for the PCA, DV-PC regression, capped DV-PC regression, and log-normal distribution fitting analyses.

The code is prepared for transparent review and reproducible analysis. Local Windows paths such as `D:\...` were removed. All input files, output folders, parameter names, log-transformed variables, PC columns, and capping rules are controlled by `config_template.json`.

## Repository structure

```text
flow_duration_reproducible_code_package/
├── README.md
├── config_template.json
├── requirements.txt
├── CITATION.cff
├── LICENSE
├── data/
│   └── README.md
├── outputs/
│   └── .gitkeep
├── docs/
│   ├── original_to_clean_mapping.md
│   └── reviewer_readiness_checklist.md
└── scripts/
    ├── 01_pca_analysis.py
    ├── 02_dv_pc_regression_noncapped.py
    ├── 03_dv_pc_regression_capped_0_1.py
    ├── 04_lognormal_distribution_fitting.py
    ├── regression_workflow.py
    └── utils.py
```

## Script purpose

| Script | Purpose | Main output |
|---|---|---|
| `01_pca_analysis.py` | PCA of catchment/input descriptors after optional log transformation and z-score standardization | PCA scores, explained variance, loadings, preprocessing workbook |
| `02_dv_pc_regression_noncapped.py` | DV-PC regression without clipping predictions to a fixed range | correlation tables, OLS regression tables, formulas, observed-vs-predicted plots |
| `03_dv_pc_regression_capped_0_1.py` | DV-PC regression for bounded variables; predictions are clipped to `[0, 1]` by default | same regression outputs plus a record of whether capping was applied |
| `04_lognormal_distribution_fitting.py` | Fitting a normal distribution to log-transformed normalized positive flow values | Q-Q plots, group plots, panel maps, fit metrics |

## Installation

Create a clean Python environment, then install the required packages:

```bash
pip install -r requirements.txt
```

Tested with Python 3.10+.

## Input data

Place the input Excel files inside the `data/` folder, or edit `config_template.json` to point to their location.

The package does not assume fixed parameter names. Edit these fields when the parameter dataset changes:

```json
"parameter_columns": ["Forest", "SoilB", "SoilC", "..."],
"log_transform_columns": ["MAP", "Hmean", "L", "PET"]
```

For the regression scripts, `parameter_columns` may be left as an empty list:

```json
"parameter_columns": []
```

In that case, the script reads the parameter names directly from the row index of `PCA_loadings_ALL_PC.xlsx`. This is useful when the PCA input descriptors change between analyses.

## How to run

Run the scripts from the repository root.

### 1. PCA analysis

```bash
python scripts/01_pca_analysis.py --config config_template.json --section pca_analysis
```

### 2. Non-capped DV-PC regression

Use this for variables that are not physically bounded by 0 and 1.

```bash
python scripts/02_dv_pc_regression_noncapped.py --config config_template.json --section dv_regression_noncapped
```

### 3. Capped DV-PC regression

Use this for bounded variables, such as intermittency/fraction/probability-type DVs. By default, predictions are clipped to `[0, 1]`.

```bash
python scripts/03_dv_pc_regression_capped_0_1.py --config config_template.json --section dv_regression_capped_0_1
```

To apply the cap only to unit-interval variables detected by name/range, change this field in the config:

```json
"cap_mode": "auto_unit_interval"
```

To cap all DVs in this script, keep:

```json
"cap_mode": "all"
```

### 4. Log-normal distribution fitting

```bash
python scripts/04_lognormal_distribution_fitting.py --config config_template.json --section lognormal_distribution_fitting
```

## Main reproducibility settings

The following settings are saved in the output workbooks or summary files:

- selected parameter columns;
- log-transformed columns;
- PCA mean and standard deviation used for z-score standardization;
- selected PC columns;
- station merge mode;
- skipped rows caused by missing/non-positive values;
- prediction capping status;
- Q-Q fitting settings.

## Suggested manuscript code-availability text

The Python scripts used to perform the PCA, DV-PC regression, capped DV-PC regression, and log-normal distribution fitting analyses are available at: `[GitHub repository URL]`. A permanent archived version is available at: `[Zenodo DOI]`. The repository includes the configuration file, package requirements, and instructions required to reproduce the reported outputs.

## Notes for reviewers

1. The scripts are independent and can be run separately.
2. Input filenames in `config_template.json` are examples and should be updated to match the provided data files.
3. Regression scripts can infer parameter names from the PCA loadings file when `parameter_columns` is left empty.
4. Capping is not applied in the non-capped script.
5. The capped script records capping information in the output sheet `Obs_vs_Pred_plots`.
