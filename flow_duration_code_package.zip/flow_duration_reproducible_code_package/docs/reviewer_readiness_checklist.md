# Reviewer readiness checklist

Before uploading to GitHub, check the following:

- [ ] Replace example file names in `config_template.json` with the actual input files.
- [ ] Confirm `parameter_columns` matches the input parameter file used for PCA.
- [ ] Confirm `log_transform_columns` contains only positive-valued variables.
- [ ] Confirm `pc_columns` matches the PCA components used in the regression models.
- [ ] Use `02_dv_pc_regression_noncapped.py` for unbounded DVs.
- [ ] Use `03_dv_pc_regression_capped_0_1.py` only for bounded DVs such as fractions, probabilities, or intermittency parameters.
- [ ] Run each script once from the repository root.
- [ ] Check generated Excel files in `outputs/`.
- [ ] Check that no private local path, username, or unpublished sensitive data is included.
- [ ] Create a GitHub release and archive the release on Zenodo to obtain a DOI.
