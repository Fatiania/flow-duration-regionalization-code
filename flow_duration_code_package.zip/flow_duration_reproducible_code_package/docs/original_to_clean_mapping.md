# Original-to-clean script mapping

| Original uploaded script | Clean GitHub/reviewer script | Comment |
|---|---|---|
| `PCA.py` | `scripts/01_pca_analysis.py` | PCA workflow with configurable parameter columns and log-transform columns. |
| `DV.PY` | `scripts/02_dv_pc_regression_noncapped.py` | General DV-PC regression without [0, 1] prediction capping. |
| `DV1.py` | `scripts/03_dv_pc_regression_capped_0_1.py` | General DV-PC regression with configurable prediction capping, default `[0, 1]`. |
| `log_transformes_10.py` | `scripts/04_lognormal_distribution_fitting.py` | Log-normal distribution fitting and Q-Q plot workflow. |

The clean scripts remove fixed local paths and avoid fixed parameter assumptions by reading paths, parameters, PC columns, and capping rules from `config_template.json`.
